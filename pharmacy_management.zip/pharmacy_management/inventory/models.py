from django.db import models

# Company Model
class Company(models.Model):
    name = models.CharField(max_length=255)
    address = models.TextField()
    phone = models.CharField(max_length=15)

    def __str__(self):
        return self.name

# Users Model
class Users(models.Model):
    name = models.CharField(max_length=255)
    dob = models.DateField()
    password = models.CharField(max_length=255)
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    phone = models.CharField(max_length=15)
    address = models.TextField()

    def __str__(self):
        return self.name

# Drugs Model
class Drugs(models.Model):
    name = models.CharField(max_length=255)
    type = models.CharField(max_length=100)
    dose = models.CharField(max_length=50)
    barcode = models.CharField(max_length=50)
    cost_price = models.DecimalField(max_digits=10, decimal_places=2)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField()
    production_date = models.DateField()
    expiration_date = models.DateField()
    company = models.ForeignKey(Company, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

# Sales Model
class Sales(models.Model):
    drug = models.ForeignKey(Drugs, on_delete=models.CASCADE)
    date = models.DateField()
    quantity = models.IntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    amount = models.DecimalField(max_digits=10, decimal_places=2)

# History Sales Model
class HistorySales(models.Model):
    sales = models.ForeignKey(Sales, on_delete=models.CASCADE)
    user_name = models.CharField(max_length=255)
    time = models.TimeField()
    date = models.DateField()

# Expiry Model
class Expiry(models.Model):
    product_name = models.CharField(max_length=255)
    product_code = models.CharField(max_length=50)
    quantity_remaining = models.IntegerField()
    date_of_expiry = models.DateField()
