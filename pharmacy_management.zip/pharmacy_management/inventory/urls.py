from django.urls import path
from . import views

app_name = 'inventory'

urlpatterns = [
    path('', views.home, name='home'),
    path('add_drug/', views.add_drug, name='add_drug'),
    path('sell_drug/', views.sell_drug, name='sell_drug'),
    path('view_inventory/', views.view_inventory, name='view_inventory'),
    path('sales_history/', views.sales_history, name='sales_history'),
    path('record_sale/', views.record_sale, name='record_sale'),
    path('expiry_list/', views.expiry_list, name='expiry_list'),
    path('add_company/', views.add_company, name='add_company'),
    path('delete_drug/<int:drug_id>/', views.delete_drug, name='delete_drug'),
]
