from django.contrib import admin
from .models import Drugs, Users, Sales, Company, HistorySales, Expiry

# Register models for the admin site
admin.site.register(Drugs)
admin.site.register(Users)
admin.site.register(Sales)
admin.site.register(Company)
admin.site.register(HistorySales)
admin.site.register(Expiry)
