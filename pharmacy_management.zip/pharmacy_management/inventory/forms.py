from django import forms
from .models import Drugs

class DrugForm(forms.ModelForm):
    class Meta:
        model = Drugs
        fields = ['name', 'type', 'barcode', 'cost_price', 'selling_price', 'quantity', 'production_date', 'expiration_date', 'company']
from .models import Sales, HistorySales, Expiry

class SalesForm(forms.ModelForm):
    class Meta:
        model = Sales
        fields = ['drug', 'date', 'quantity', 'price', 'amount']

class ExpiryForm(forms.ModelForm):
    class Meta:
        model = Expiry
        fields = ['product_name', 'product_code', 'quantity_remaining', 'date_of_expiry']
