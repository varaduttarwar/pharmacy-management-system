from django.shortcuts import render,redirect
from .models import Drugs, Sales, HistorySales, Company, Expiry
from django.utils import timezone
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.urls import reverse

# Home page view
def home(request):
    return render(request, 'inventory/home.html')

# Add drug view
def add_drug(request):
    if request.method == 'POST':
        # Get form data
        name = request.POST['name']
        company_name = request.POST['company_name']
        company_address = request.POST['company_address']
        company_phone = request.POST['company_phone']

        # Check if the company already exists (based on name)
        company, created = Company.objects.get_or_create(
            name=company_name,
            address=company_address,
            phone=company_phone
        )

        # If the company is created, it will be a new company.
        # You can log this or take any additional action as needed.

        # Get other drug details
        drug_type = request.POST['type']
        dose = request.POST['dose']
        barcode = request.POST['barcode']
        cost_price = request.POST['cost_price']
        selling_price = request.POST['selling_price']
        quantity = request.POST['quantity']
        production_date = request.POST['production_date']
        expiration_date = request.POST['expiration_date']

        # Create the drug and associate it with the company
        drug = Drugs.objects.create(
            name=name,
            type=drug_type,
            dose=dose,
            barcode=barcode,
            cost_price=cost_price,
            selling_price=selling_price,
            quantity=quantity,
            production_date=production_date,
            expiration_date=expiration_date,
            company=company
        )
        drug.save()
        # Redirect to view inventory page after adding the drug
        return redirect('inventory:view_inventory')

    return render(request, 'inventory/add_drug.html')

# Sell drug view
def sell_drug(request):
    if request.method == 'POST':
        # Logic to sell a drug
        drug_id = request.POST['drug_id']
        quantity_sold = request.POST['quantity']
        drug = Drugs.objects.get(id=drug_id)
        amount = drug.selling_price * quantity_sold

        # Create a sales record
        sale = Sales.objects.create(
            drug=drug,
            quantity=quantity_sold,
            price=drug.selling_price,
            amount=amount,
            date=request.POST['date']
        )

        # Update drug quantity
        drug.quantity -= quantity_sold
        drug.save()

        # Create a history sales record
        HistorySales.objects.create(
            sales=sale,
            user_name=request.user.username,
            time=request.POST['time'],
            date=request.POST['date']
        )

        return redirect('inventory:sales_history')
    return render(request, 'inventory/sell_drug.html')

# View inventory page
def view_inventory(request):
    # Fetch all drugs from the database
    drugs = Drugs.objects.all()  # This will fetch all drugs including the new ones

    # Pass drugs to the template
    return render(request, 'inventory/view_inventory.html', {'drugs': drugs})


def delete_drug(request, drug_id):
    drug = get_object_or_404(Drugs, id=drug_id)
    drug.delete()
    return redirect('inventory:view_inventory')

# Sales history page
def record_sale(request):
    if request.method == 'POST':
        drug_barcode = request.POST.get('barcode')
        quantity = int(request.POST.get('quantity'))
        price = float(request.POST.get('price'))
        amount = float(request.POST.get('amount'))

        # Check if the drug exists using the barcode
        try:
            drug = Drugs.objects.get(barcode=drug_barcode)
        except Drugs.DoesNotExist:
            return render(request, 'inventory/record_sale.html', {'error': 'Drug not found'})

        # Record the sale in the Sales table
        sale = Sales.objects.create(
            drug=drug,
            date=timezone.now().date(),
            quantity=quantity,
            price=price,
            amount=amount
        )

        # Record the sale in HistorySales with user information and timestamp
        HistorySales.objects.create(
            sales=sale,
            user_name=request.user.username if request.user.is_authenticated else "Anonymous",
            time=timezone.now().time(),
            date=timezone.now().date()
        )

        return redirect('inventory:sales_history')

    return render(request, 'inventory/record_sale.html')

def sales_history(request):
    # Fetch the sales history with related drug information for each sale
    sales_history = HistorySales.objects.select_related('sales', 'sales__drug')
    return render(request, 'inventory/sales_history.html', {'sales_history': sales_history})


def expiry_list(request):
    # Get today's date
    today = timezone.now().date()

    # Filter drugs whose expiry date is near (within 30 days)
    expiry_soon = Drugs.objects.filter(expiration_date__lte=today + timezone.timedelta(days=30))

    # Pass the expiry data to the template
    return render(request, 'inventory/expiry_list.html', {'expiry_soon': expiry_soon})


def add_company(request):
    if request.method == 'POST':
        # Get form data
        name = request.POST['name']
        address = request.POST['address']
        phone = request.POST['phone']

        # Create a new company
        company = Company.objects.create(
            name=name,
            address=address,
            phone=phone
        )

        # Redirect to view_inventory or another relevant page
        return redirect('inventory:view_inventory')

    # Render the add_company template
    return render(request, 'inventory/add_company.html')